from flask import Flask, render_template, jsonify
from flask_sqlalchemy import SQLAlchemy
import random
from datetime import datetime, timedelta

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///sales.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# Define the Sales model with product, price, and date_sold
class Sales(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    product = db.Column(db.String(50), nullable=False)
    price = db.Column(db.Float, nullable=False)
    date_sold = db.Column(db.String(50), nullable=False)

    def __repr__(self):
        return f'<Sales {self.product}>'

# Function to insert dummy data
def insert_dummy_data():
    # Ensure we're within the application context
    with app.app_context():
        # Drop existing tables and create new ones
        db.drop_all()
        db.create_all()

        # Products and their prices
        products = {
            'Laptop': 1000.00,
            'Smartphone': 700.00,
            'Headphones': 150.00,
            'Smartwatch': 200.00,
            'Tablet': 300.00
        }

        # Generate 50 dummy sales records with varying sales and dates
        for _ in range(50):
            product = random.choice(list(products.keys()))
            price = products[product]
            sales = random.randint(1, 10)  # Random sales between 1 and 10 units
            total_price = price * sales
            random_days = random.randint(1, 365)  # Random number of days from now
            date = datetime.now() - timedelta(days=random_days)
            formatted_date = date.strftime('%Y-%m-%d')  # Format date as YYYY-MM-DD

            # Create and add the sales record to the database
            sale = Sales(product=product, price=total_price, date_sold=formatted_date)
            db.session.add(sale)

        # Commit the changes to the database
        db.session.commit()

# Call the function to insert the dummy data inside the application context
insert_dummy_data()

@app.route('/')
def index():
    return render_template('bar_chart.html')


@app.route('/pie')
def pie_chart():
    return render_template('pie_chart.html')


@app.route('/histogram')
def histogram_chart():
    return render_template('histogram.html')


@app.route('/data')
def get_data():
    # Fetch all sales data from the database
    sales_data = Sales.query.all()
    data = [{"product": sale.product, "price": sale.price, "date_sold": sale.date_sold} for sale in sales_data]
    return jsonify(data)


if __name__ == '__main__':
    app.run(debug=True)
